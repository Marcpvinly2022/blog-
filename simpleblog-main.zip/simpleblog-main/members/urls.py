from django.urls import path 
from .views import register_view, login_view, logout_view,UserEditView,PasswordChangingView,ShowProfileView, EditProfilePageView,CreateUserProfilePage
from .import  views 

urlpatterns = [
    path('', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('edit_profile/', UserEditView.as_view(), name='edit_profile'),
    path('password/', PasswordChangingView.as_view(template_name="account/change_password.html"), name='change_password'),
    path('password_success/', views.password_success, name='password_success'),
    path('members/<int:pk>/profile/', ShowProfileView.as_view(), name='user_profile'),
    path('members/<int:pk>/edit_profile_page/', EditProfilePageView.as_view(), name='edit_profile_page'),
    path('create_user_profile_page/', CreateUserProfilePage.as_view(), name='create_user_profile_page'),
   
  
]
