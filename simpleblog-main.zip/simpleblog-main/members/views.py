'''
from django.shortcuts import render
from django.views import generic
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy

# Create your views here.

class UserRegisterView(generic.CreateView):
    form_class = UserCreationForm
    template_name = 'Registration/register.html'
    success_url = reverse_lazy('login')

'''


from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth import login , logout , authenticate
from .form import RegisterForm,EditProfileForm,EditProfileForm,PasswordChangingForm,ProfilePageForm,EditPageForm
from django.views import generic
from django.urls import reverse_lazy
from django.contrib.auth.views import PasswordChangeView
from django.views.generic import DetailView,CreateView
from theblog.models import Profile,Comment


class CreateUserProfilePage(CreateView):
    form_class =ProfilePageForm
    model = Profile
    template_name = 'account/create_user_profile_page.html'
    #fields =['bio','profile_pic','website_url','facebook_url','intagram_url','pinterest_url']
    #logic to grab the user profile form, take id put it on form as user
    def form_valid(self, form):
        form.instance.user= self.request.user #take id put it on form as user
        return super().form_valid(form)

class  EditProfilePageView(generic.UpdateView):
    form_class =  EditPageForm
    model = Profile
    template_name = 'account/edit_profile_page.html'
    #fields= ['bio','profile_pic','website_url','facebook_url','intagram_url','pinterest_url']
    success_url = reverse_lazy('home')

class ShowProfileView(DetailView):
    model = Profile
    template_name = 'account/user_profile.html'
    
    def get_context_data(self, *args,**kwargs):
        #users =Profile.objects.all()
        context= super(ShowProfileView,self).get_context_data(*args,**kwargs)
        user_page = get_object_or_404(Profile, pk=self.kwargs['pk'])
        context ['user_page']= user_page
        return context
        

def password_success(request):
    return render(request,'account/password_success.html',{})

class PasswordChangingView(PasswordChangeView):
    form_class = PasswordChangingForm
    success_url = reverse_lazy('password_success')


# Create your views here.
  # Make sure to import your RegisterForm
class UserEditView(generic.UpdateView):
    form_class = EditProfileForm
    template_name= 'account/edit_profile.html'
    success_url = reverse_lazy('home')
    #To get the current user
    def get_object(self):
        return self.request.user

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('login')  # Redirect to named URL 'login' instead of hardcoded path
    else:
        form = RegisterForm()
    
    return render(request, 'account/register.html', {'form': form})
    
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'account/login.html', {'error': 'Invalid credentials '})
    return render(request, 'account/login.html')  


'''def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'account/login.html', {'error': 'Invalid credentials'})
    return render(request, 'account/login.html')
'''
def logout_view(request):
    logout(request)
    return redirect('login')   
     
