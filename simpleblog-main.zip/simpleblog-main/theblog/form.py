from django import forms
from .models import Post,Category,Comment



#chioces = [('Coding', 'Coding'),('Sports', 'Sports'),('Entertainment', 'Entertainment')]
choices = Category.objects.all().values_list('name', 'lname')



choice_list = []

for item,name in choices:
   choice_list.append((item,name))
    
    

class FormPost(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title','author','category','body','snippet','header_image')
    
        widgets ={
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'author': forms.Select(attrs={'class': 'form-control'}),
            'category': forms.Select(choices=choice_list, attrs={'class': 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control'}),
            'snippet': forms.Textarea(attrs={'class': 'form-control'}),
            }
    
    
 
class EditPost(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title','body','snippet')
    
        widgets ={
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'snippet': forms.TextInput(attrs={'class': 'form-control'}),
            #'author': forms.Select(attrs={'class': 'form-control'}),
           
            'body': forms.Textarea(attrs={'class': 'form-control'}),
            }
    
    
 
 
class AddCommet(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ('name','body')
    
        widgets ={
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control'}),
            }
    
    
 