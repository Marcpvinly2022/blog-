# simpleblog
simple blog with django
